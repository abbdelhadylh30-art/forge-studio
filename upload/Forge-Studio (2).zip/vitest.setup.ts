import "@testing-library/jest-dom/vitest";

// jsdom DOES implement getBoundingClientRect but always returns zeros (no
// layout engine), which the scoring engine treats as "hidden". Override it
// unconditionally so tests can simulate layout via element.dataset._rect.
const origGBCR = HTMLElement.prototype.getBoundingClientRect;
HTMLElement.prototype.getBoundingClientRect = function () {
  const raw = (this as HTMLElement & { dataset?: DOMStringMap }).dataset?._rect;
  if (raw) {
    try {
      const r = JSON.parse(raw);
      return {
        x: r.x ?? 0, y: r.y ?? 0,
        top: r.top ?? 0, left: r.left ?? 0,
        right: r.right ?? 0, bottom: r.bottom ?? 0,
        width: r.width ?? 0, height: r.height ?? 0,
        toJSON: () => ({ x: r.x ?? 0, y: r.y ?? 0, top: r.top ?? 0, left: r.left ?? 0, right: r.right ?? 0, bottom: r.bottom ?? 0, width: r.width ?? 0, height: r.height ?? 0 }),
      };
    } catch {
      /* fall through to origGBCR */
    }
  }
  return origGBCR.call(this);
};

// matchMedia is not implemented in jsdom.
if (!window.matchMedia) {
  window.matchMedia = (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => false,
  });
}
