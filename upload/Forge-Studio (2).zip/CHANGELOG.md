# Changelog

All notable changes to Forge Studio are documented in this file. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

This release applies SWEBOK v3.0 software-engineering practices across 15 Knowledge Areas. Each entry references the relevant KA.

## [1.2.0] — 2026-07-05

### Added — SWEBOK KA 4 §2.3 (Test coverage gaps)
- **6 new test suites** (56 new tests, 137 total across 13 suites):
  - `url-guard-async.test.ts` (10 tests) — `assertPublicUrl` with mocked `dns.lookup`: protocol validation, literal-IP rejection, hostname resolution, DNS failure, mixed-record rejection.
  - `fetch-url/route.test.ts` (8 tests) — integration tests: missing url → 400, private IP → 400 (fetch NOT called), 5MB cap → 413, non-HTML → 415, 404 → 502, sanitized HTML output.
  - `ai-copy/route.test.ts` (10 tests) — zod validation, happy path, quote-trimming, fallback when SDK throws, fallback on empty response, rate-limit 10/min → 429 on 11th.
  - `rate-limit.test.ts` (10 tests) — sliding window, bucket isolation, replenishment, `retryAfterMs` bounds, `getClientIp` header parsing.
  - `forge/store.test.ts` (7 tests) — transfer bridge + stale-guard TTL (discard >60s, accept <60s).
  - `engine-server.test.ts` (5 tests) — `runScoringFromHTML` via jsdom, structure parity, malformed HTML, empty doc.

### Added — SWEBOK KA 3 §4.3 (Rate limiting)
- `lib/security/rate-limit.ts` — in-memory sliding-window rate limiter (10 req/min per IP on the AI copy endpoint). Returns 429 with `Retry-After` header. `getClientIp` extracts from `X-Forwarded-For` / `X-Real-IP`.
- Wired into `api/ai-copy/route.ts`.

### Added — SWEBOK KA 3 §8 (Server-side scoring)
- `lib/pixelforge/scoring/server.ts` — `runScoringFromHTML(html)` entry point using jsdom. Dynamic import keeps jsdom out of the client bundle (engine.ts is imported by client components; server.ts is server-only).
- Documented the jsdom layout caveat: above-fold / touch-target / contrast checks score as if everything is at (0,0). For accurate server-side scores, use a headless browser (Playwright) to render, then pass its `Document` to `runScoring`. This unlocks the Monitor feature's quick "did anything change?" signal.

### Added — SWEBOK KA 10 §2.2 (Self-measurement)
- `runScoring` now wraps itself with `performance.now()` and emits a dev-mode `console.warn` if the call exceeds 500ms (PERF_WARN_MS). Reports DOM size for context. Zero-cost in production (guarded on `NODE_ENV`).

### Changed — SWEBOK KA 2 §4.1 (Transfer bridge overflow guard)
- `lib/forge/store.ts` — `consumeTransfer()` now discards payloads older than `TRANSFER_TTL_MS` (60s). If the user navigates away before the receiving tool mounts, the stale HTML is discarded on the next read instead of sitting in memory indefinitely.

### Removed — SWEBOK KA 6 §2.1 (Dead configuration items)
- `prisma/schema.prisma` — removed the `Monitor` model (8 fields: schedule, threshold, isActive, lastCheckAt, lastScore, history, etc.) and the `monitors Monitor[]` relation on `Project`. The model was fully defined but had zero implementation; keeping it would create migration debt on the PostgreSQL move.
- `lib/pixelforge/types.ts` — removed the unused `MonitorHistoryItem` interface.

## [1.1.0] — 2026-07-05

### Added — SWEBOK KA 1 (Software Requirements)
- **REQUIREMENTS.md** — functional + non-functional requirements spec with tracing.
- **ARCHITECTURE.md** — layering, state management, scoring pipeline, security model, testing strategy, known tech debt.

### Added — SWEBOK KA 4 (Software Testing)
- **Vitest test suite** (7 files, 81 tests) covering the previously-untested core logic:
  - `engine.test.ts` (19 tests) — `parseColor`, `lum`, `getContrastRatio`, `runScoring` categories, and **regression tests** for the `ctaWords` substring bug and the unlabeled-count off-by-one bug.
  - `quick-fixes.test.ts` (13 tests) — `fixMultipleH1` data-loss regression, no-op guards, `applyAllSafeFixes` batch behavior.
  - `url-guard.test.ts` (10 tests) — `isPrivateIP` boundary cases (RFC1918, loopback, link-local, CGNAT, IPv6).
  - `sanitize.test.ts` (14 tests) — filename injection vectors, active-content stripping.
  - `renderer.test.ts` (6 tests) — HTML escaping (XSS), section rendering, title fallbacks.
  - `builder-store.test.ts` (13 tests) — undo/redo, addPage/removePage, duplicateSection, theme tokens.
  - `theme-utils.test.ts` (6 tests) — theme-to-CSS mapping, icon resolution.
- `vitest.config.ts`, `vitest.setup.ts` (jsdom + `getBoundingClientRect` override for above-fold simulation).
- `test` and `test:watch` scripts in `package.json`.

### Added — SWEBOK KA 5 (Software Maintenance) & KA 8 (SE Process)
- **CHANGELOG.md** (this file).
- **CONTRIBUTING.md** — development setup, test/lint workflow, PR process, SWEBOK-aligned coding standards.
- **LICENSE** (MIT) — the README claimed MIT but no LICENSE file existed.

### Added — SWEBOK KA 2 §2.7 (Security) & KA 3 §4.5 (Fault Tolerance)
- `lib/security/url-guard.ts` — SSRF guard (`assertPublicUrl`, `isPrivateIP`) that resolves hostnames and rejects private/loopback/link-local/CGNAT/multicast IPs.
- `lib/security/sanitize.ts` — `sanitizeFilename` (header-injection defense) and `stripActiveContent` (defense-in-depth HTML sanitizer).

### Changed — SWEBOK KA 3 §4.5 (Defensive Programming)
- **`api/fetch-url/route.ts`** — rewrote with SSRF guard, 8s timeout (was 12s), 5MB size cap, improved sanitizer (strips `<object>/<embed>/<base>`, meta-refresh, `javascript:` URIs in all URL attributes).
- **`api/ai-copy/route.ts`** — rewrote with zod validation, prompt-injection fencing (`<UNTRUSTED>` delimiters + explicit ignore instruction), proper error messages.
- **`api/export/route.ts`** — sanitized the ZIP filename via `sanitizeFilename` (was raw `site.slug`).
- **`api/export-html/route.ts`** — sanitized the download filename via `sanitizeFilename`; added type guard on `body.html`.
- Fixed the broken `@/lib/sections/types` import → `@/lib/builder/sections/types`.

### Fixed — SWEBOK KA 3 (Construction) & KA 5 (Maintenance)
- **`fixMultipleH1` data-loss bug** — the H1→H2 demotion previously set `h2.textContent` BEFORE moving children, duplicating text and destroying inner HTML (links, spans). Now moves children only.
- **`Preview.tsx` click-handler leak** — the iframe `load` effect never registered `attachListeners()`'s cleanup, so every state change layered a new capture-phase click handler. Now captures and invokes `detach` on cleanup.
- **`ScorePanel.tsx` stale-score bug** — `handleFix`/`handleFixAll` read `scoreData.score` synchronously after `syncHTML`, but re-scoring happens in `requestAnimationFrame`, so the diff was always 0. Now calls `runScoring` directly to compute the new score immediately.
- **`applyAllSafeFixes` history pollution** — "Fix All" previously pushed one history entry per fix (up to 38). Now pushes a single snapshot before the batch and uses `setHTML(html, { skipHistory: true })` for intermediate commits.
- **Quick-fix no-op returns** — 13 fixes returned `applied: true` even when `fixed === 0`, polluting the changelog. Now guard with `if (fixed === 0) return { applied: false }`.
- **`engine.ts` `ctaWords` false positives** — "now" matched as a substring of "knowledge", "snow", "nowhere". Now uses `\b` word boundaries.
- **`engine.ts` unlabeled-count off-by-one** — `Math.ceil(inputs.length - labeled)` double-counted placeholder-only fields. Now counts fully-unlabeled inputs directly.
- **`Inspector.tsx` label/input mismatch** — `Label htmlFor` was `${sectionId}-${field.key}` but `Input id` was just `field.key`. Now both use `${sectionId}-${field.key}` (also fixes duplicate-ID collisions across sections).
- **`builder-store.ts removePage` mutation** — directly mutated `filtered[0].isHome = true` on the original `PageData`. Now builds a new array with a spread copy.
- **`EditPanel.tsx` React-Compiler violations** — mutated state-stored `HTMLElement` directly. Now stores the element in a `useRef` and derives `hasElement` from the selector during render.
- **`OGPanel.tsx` setState-in-effect** — switched to `useMemo` derivation from `currentHTML` (no effect needed).
- **`GuideOverlay.tsx` setState-in-effect** — removed the synchronous `setSpotlightRect(null)` in the effect body; the render guard handles the inactive case.

### Removed — SWEBOK KA 6 (Software Configuration Management)
- **Deleted the duplicated `forge-studio/Forge-Studio/` directory** (~135 files, ~6 MB of dead weight that caused 4 duplicate lint errors). The live project at the repo root is the single source of truth.

### Changed — SWEBOK KA 6 (SCM)
- **`.gitignore`** — added `tool-results/`, `upload/`, `db/*.db`, `db/*.db-journal`, `/forge-studio/`.
- **`.env.example`** — added so new contributors have a template.
- **`eslint.config.mjs`** — the 4 React-Compiler errors are now resolved (was 9 errors, now 0).

## [1.0.0] — prior

Initial Forge Studio release (combined LandingForge v4.0 builder + PixelForge v19 auditor under one roof). See the git history for details.
