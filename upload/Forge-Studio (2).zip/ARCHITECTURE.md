# Forge Studio — Architecture

**SWEBOK KA:** Software Design (Chapter 2)

This document describes the architecture, layering, key design decisions, and security model of Forge Studio.

## 1. Layering

The codebase follows a strict three-layer structure:

```
┌─────────────────────────────────────────────────────────────┐
│  app/                      (Next.js App Router — entry)     │
│   ├── page.tsx             view switcher (dashboard/builder/│
│   │                        templates/auditor)               │
│   ├── layout.tsx           Inter font + metadata            │
│   ├── globals.css          dark auditor + light builder     │
│   └── api/                 server-side routes               │
│        ├── fetch-url/      CORS proxy (SSRF-guarded)        │
│        ├── ai-copy/        z-ai-web-dev-sdk (prompt-fenced) │
│        ├── export/         HTML/ZIP export (filename-safe)  │
│        └── export-html/    HTML download (filename-safe)    │
├─────────────────────────────────────────────────────────────┤
│  components/               (React UI)                       │
│   ├── forge/               dashboard + auditor shell        │
│   ├── builder/             page builder editor + sections   │
│   └── pixelforge/          auditor editor + panels + modals │
├─────────────────────────────────────────────────────────────┤
│  lib/                      (pure logic — framework-agnostic)│
│   ├── forge/store.ts       top-level view + transfer store  │
│   ├── builder/             section types, registry, render  │
│   │   ├── sections/        types, registry, theme, renderer │
│   │   ├── store/           Zustand (50-deep history)        │
│   │   └── templates/       5 site blueprints                │
│   ├── pixelforge/          scoring, fixes, store, types     │
│   │   ├── scoring/         engine (1236 LOC, pure)          │
│   │   ├── fixes/           35+ quick-fixes (pure)           │
│   │   ├── store/           Zustand (80-deep history)        │
│   │   └── types.ts         ScoreData, Issue, ChangeLogItem  │
│   └── security/            SSRF guard + sanitizers          │
└─────────────────────────────────────────────────────────────┘
```

**Dependency rule:** `app/` → `components/` → `lib/`. `lib/` never imports from `components/` or `app/`. This keeps the core logic (scoring, fixes, renderer) testable without React.

## 2. State Management

Three Zustand stores, each with a single responsibility:

| Store | Scope | History |
|-------|-------|---------|
| `useForge` (`lib/forge/store.ts`) | Top-level view + transfer bridge | none |
| `useBuilder` (`lib/builder/store/builder-store.ts`) | Site blueprint, pages, sections, theme, undo/redo | 50 snapshots |
| `usePFStore` (`lib/pixelforge/store/pf-store.ts`) | Current HTML, score, mode, device, undo/redo, changelog | 80 snapshots |

**Subscription pattern:** Components subscribe via `useStore((s) => s.field)` selectors (not whole-store destructuring) to minimize re-renders. (A future iteration should migrate remaining whole-store subscriptions to `useShallow`.)

## 3. The Auditor's Scoring Pipeline

The auditor's core IP is the scoring engine (`lib/pixelforge/scoring/engine.ts`, 1236 LOC). It is a **pure function**: `runScoring({ doc, viewportWidth })` reads from a `Document` and returns a `ScoreData` without mutating anything. This purity is what makes it testable — the test suite (`engine.test.ts`, 19 tests) constructs `Document` instances via `DOMParser` and asserts on the returned scores.

The pipeline:
1. The `Preview` component writes `currentHTML` into the iframe via `srcdoc`.
2. On iframe `load`, `attachListeners()` (click-to-select in edit mode) and `rescore()` run.
3. `rescore()` calls `runScoring({ doc })` inside a `requestAnimationFrame` (so the DOM has time to lay out — `getBoundingClientRect` is used for above-fold checks).
4. The resulting `ScoreData` is stored in `usePFStore.scoreData`.
5. The `ScorePanel` reads `scoreData` and renders the gauge, category breakdown, and issue list.

Quick-fixes mutate the iframe `Document` directly, then call `syncHTML()` which serializes the doc back to `currentHTML` and triggers a re-score.

## 4. The Builder's Section System

The builder is schema-driven: each of the 12 section kinds has a `FieldSchema[]` definition in `lib/builder/sections/registry.ts`. The `Inspector` component auto-generates a form from this schema (text inputs, textareas, color pickers, selects, switches, repeatable list editors). The `renderSiteHTML` function (`lib/builder/sections/renderer.ts`) turns the section JSON into standalone HTML via pure string templating (no React on the server side — exports are dependency-free and hostable anywhere).

## 5. Security Model

| Threat | Mitigation | Location |
|--------|-----------|----------|
| SSRF (server-side URL proxy used to scan internal services) | `assertPublicUrl` resolves the hostname and rejects private/loopback/link-local IPs | `lib/security/url-guard.ts`, `api/fetch-url/route.ts` |
| XSS via fetched HTML | `stripActiveContent` removes scripts, on* handlers, javascript: URIs, `<object>/<embed>/<base>`, meta-refresh; iframe is sandboxed (no `allow-scripts`) | `lib/security/sanitize.ts`, `Preview.tsx` |
| Prompt injection via AI copy | User-supplied text is fenced in `<UNTRUSTED>` blocks with an explicit instruction to ignore embedded commands; zod validates the request | `api/ai-copy/route.ts` |
| Header injection via export filenames | `sanitizeFilename` strips path separators, quotes, and control chars before `Content-Disposition` | `lib/security/sanitize.ts`, `api/export/route.ts`, `api/export-html/route.ts` |
| Iframe script execution | `sandbox="allow-same-origin allow-popups allow-forms"` (no `allow-scripts`) on untrusted content | `Preview.tsx`, `SectionRenderer.tsx` |

**Known limitation:** The HTML sanitizer is regex-based (defense-in-depth). For full-strength sanitization, a future iteration should adopt `isomorphic-dompurify`. The iframe sandbox remains the primary mitigation.

## 6. Testing Strategy (KA 4)

The test suite (`vitest`) focuses on the pure logic layer:

| Module | Tests | Coverage focus |
|--------|-------|----------------|
| `lib/security/url-guard.ts` | 10 | `isPrivateIP` boundary cases (RFC1918, loopback, link-local, CGNAT, IPv6) |
| `lib/security/sanitize.ts` | 14 | filename injection vectors, active-content stripping |
| `lib/pixelforge/scoring/engine.ts` | 19 | `parseColor`, `lum`, `getContrastRatio`, `runScoring` categories, bug regressions |
| `lib/pixelforge/fixes/quick-fixes.ts` | 13 | `fixMultipleH1` data-loss regression, no-op guards, `applyAllSafeFixes` |
| `lib/builder/sections/renderer.ts` | 6 | HTML escaping, section rendering, title/description fallbacks |
| `lib/builder/sections/theme-utils.ts` | 6 | theme-to-CSS mapping, icon resolution |
| `lib/builder/store/builder-store.ts` | 13 | undo/redo, addPage/removePage, duplicateSection, theme tokens |

Run `bun run test` to execute. The jsdom environment is configured with a `getBoundingClientRect` override (via `element.dataset._rect`) so above-fold checks can be simulated.

### v1.2.0 additions
- **API route tests** — `fetch-url/route.test.ts` (8 tests) covers the SSRF guard, 5MB cap → 413, non-HTML → 415, 404 → 502, and sanitized output. `ai-copy/route.test.ts` (10 tests) covers zod validation, the fallback path when the SDK throws, and rate-limit 429s.
- **`assertPublicUrl` tests** — `url-guard-async.test.ts` (10 tests) mocks `dns.lookup` to verify hostname resolution rejection of private IPs, DNS failures, and mixed-record rejection.
- **Rate-limit tests** — `rate-limit.test.ts` (10 tests) covers the sliding window, bucket isolation, replenishment, and `getClientIp` header parsing.
- **Transfer-bridge tests** — `forge/store.test.ts` (7 tests) covers the stale-guard TTL.
- **Server-side scoring tests** — `engine-server.test.ts` (5 tests) verifies `runScoringFromHTML` via jsdom.

## 7. Known Technical Debt

Documented for future iterations (SWEBOK KA 5 — Maintenance):
- **Prisma layer is scaffolded but unused.** `prisma/schema.prisma` defines 7 models (Project, Audit, QuickFix, etc. — Monitor was removed in v1.2.0) but `lib/db.ts` is imported nowhere. Either wire it up for project persistence or remove it.
- **30+ unused dependencies** in `package.json` (`next-auth`, `@tanstack/react-query`, `recharts`, `framer-motion`, `@mdxeditor/editor`, etc.) — candidate for a bundle-size cleanup. (`jsdom` was added to production deps in v1.2.0 for `runScoringFromHTML` — it's dynamic-imported so it stays out of the client bundle.)
- **`any` types in `export/route.ts` and `renderer.ts`** — the section render functions use `c: any` for the config object. A typed `SectionConfigMap` would eliminate these.
- **`tsconfig.json` has `noImplicitAny: false`** — flipping this to `true` (after the `any` cleanup) would catch future leaks.
- **Whole-store subscriptions** in ~20 components — migrate to `useShallow` selectors for fewer re-renders.
- **`setInterval`-based polling** in `LayerPanel` and `GuideOverlay` (800ms) — replace with `MutationObserver`.
- **Rate limiter is in-memory only** — sufficient for single-instance deployment. For multi-instance, swap the `Map` in `rate-limit.ts` for Redis.
- **Server-side scoring uses jsdom** (no layout engine) — above-fold / touch-target / contrast checks are degraded. For accurate server-side scores (e.g. the Monitor feature's scheduled re-audits), use a headless browser (Playwright/Puppeteer) to render the page, then pass its `Document` to `runScoring`.
