#!/usr/bin/env python3
"""Extract SWEBOK v3.0 PDF: TOC + key knowledge areas to a text file for study."""
import pdfplumber
import sys
from pathlib import Path

PDF = "/home/z/my-project/upload/Guide to the Software Engineering Body of Knowledge (SWEBOK(r)) Version 3.0 (Pierre Bourque, Richard E. Fairley) (z-library.sk, 1lib.sk, z-lib.sk).pdf"
OUT = "/home/z/my-project/scripts/swebok_extract.txt"

def main():
    out_lines = []
    with pdfplumber.open(PDF) as pdf:
        n = len(pdf.pages)
        out_lines.append(f"# SWEBOK v3.0 — extracted text\n# Total pages: {n}\n")
        # Extract all pages text (pdfplumber is fast enough for ~300pp)
        for i, page in enumerate(pdf.pages):
            try:
                txt = page.extract_text() or ""
            except Exception as e:
                txt = f"[extract error: {e}]"
            out_lines.append(f"\n\n===== PAGE {i+1} =====\n")
            out_lines.append(txt)
    Path(OUT).write_text("".join(out_lines), encoding="utf-8", errors="replace")
    print(f"Wrote {OUT} ({sum(len(s) for s in out_lines)} chars)")

if __name__ == "__main__":
    main()
