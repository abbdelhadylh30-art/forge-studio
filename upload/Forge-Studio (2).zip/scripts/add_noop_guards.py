#!/usr/bin/env python3
"""
Insert `if (fixed === 0) return { applied: false };` guards before syncHTML()
in every quick-fix function that uses a `let fixed = 0;` counter.

This prevents no-op fixes from polluting the changelog and history stack
(SWEBOK KA 3 §4.5 — fault tolerance; KA 5 — maintainability).

The transformation is conservative: it only inserts a guard when:
  1. A `let fixed = 0;` line exists in the current function scope.
  2. The next `syncHTML();` at 2-space indent is immediately preceded by `});`
     (the end of the forEach loop).
  3. We haven't crossed a function boundary (`const fixXxx: FixFn` or `};\n\n`).
"""
import re
from pathlib import Path

PATH = Path("/home/z/my-project/src/lib/pixelforge/fixes/quick-fixes.ts")
text = PATH.read_text()
lines = text.split("\n")

out = []
i = 0
guard = '  if (fixed === 0) return { applied: false };'
inserted = 0
while i < len(lines):
    line = lines[i]
    out.append(line)
    # Detect entering a fix function with a `fixed` counter.
    if re.match(r'^  let fixed = 0;', line):
        # Scan forward for the syncHTML() that closes this fix's mutation block,
        # stopping at function boundaries.
        j = i + 1
        has_fixed_counter = True
        sync_line = None
        while j < len(lines):
            lj = lines[j]
            # New top-level fix fn starting → bail.
            if re.match(r'^const fix\w+: FixFn', lj) or re.match(r'^const add\w+: FixFn', lj):
                break
            # The forEach ends with `  });` — the NEXT `  syncHTML();` is our target.
            if lj == '  });' and j + 1 < len(lines) and lines[j + 1] == '  syncHTML();':
                sync_line = j + 1
                break
            j += 1
        if sync_line is not None and has_fixed_counter:
            # Emit everything up to (but not including) the syncHTML line, then guard, then continue.
            for k in range(i + 1, sync_line):
                out.append(lines[k])
            out.append(guard)
            out.append('  syncHTML();')
            inserted += 1
            i = sync_line + 1
            continue
    i += 1

PATH.write_text("\n".join(out))
print(f"Inserted {inserted} no-op guards into {PATH}")
