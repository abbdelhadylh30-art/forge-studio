# Contributing to Forge Studio

**SWEBOK KA:** Software Engineering Process (Chapter 8) & Professional Practice (Chapter 11)

Thanks for contributing! This document defines the development workflow and coding standards that keep Forge Studio maintainable. All contributors are expected to follow it.

## 1. Development setup

```bash
bun install              # install dependencies
bun run dev              # start the dev server on http://localhost:3000
bun run lint             # ESLint (must pass with 0 errors)
bun run test             # run the Vitest suite (must pass)
bun run test:watch       # watch mode for TDD
```

The dev server auto-restarts on file changes. Only the `/` route is user-visible (the app uses Zustand view-switching, not routing).

## 2. The Definition of Done

A change is "done" when **all** of these are true:

- [ ] `bun run lint` passes with 0 errors.
- [ ] `bun run test` passes (no skipped tests).
- [ ] The dev server compiles without errors (check `dev.log`).
- [ ] New pure functions in `src/lib/` have unit tests.
- [ ] Security-sensitive changes (API routes, sanitizers, URL handling) have tests covering the threat model.
- [ ] The CHANGELOG is updated under the `[Unreleased]` section.
- [ ] JSDoc is added to any new exported function in `src/lib/`.

## 3. Coding standards (SWEBOK KA 3 — Software Construction)

### 3.1 Type safety
- TypeScript `strict` mode is on. Avoid `any`; if a type is genuinely unknown, use `unknown` and narrow it.
- Never use `@ts-ignore` or `@ts-expect-error` without an inline justification comment.
- Validate all API request bodies with `zod` (see `api/ai-copy/route.ts` for the pattern).

### 3.2 Error handling (KA 3 §4.5)
- API routes MUST use `try/catch` and return appropriate HTTP status codes (400 for client errors, 422 for validation, 502/504 for upstream failures).
- Never swallow errors with empty `catch {}` blocks — at minimum, log to `console.warn` with context.
- Client-side `fetch` calls MUST handle the error case (no silent fallbacks).

### 3.3 Security (KA 2 §2.7)
- Any URL fetched server-side MUST pass through `assertPublicUrl` (SSRF guard).
- Any filename placed in a `Content-Disposition` header MUST pass through `sanitizeFilename`.
- Any user-supplied text sent to the LLM MUST be fenced in `<UNTRUSTED>` blocks (see `api/ai-copy/route.ts`).
- Untrusted HTML rendered in an iframe MUST use `sandbox` without `allow-scripts`.

### 3.4 React (Next.js 16 / React 19)
- Use `'use client'` only when the component needs browser APIs or state.
- Never mutate state-stored DOM nodes — use a `useRef` (see `EditPanel.tsx`).
- Never call `setState` synchronously in an effect body — derive during render with `useMemo` where possible, or scope a `/* eslint-disable */` with a justification comment for legitimate external-sync patterns.
- Subscribe to Zustand stores via selectors (`useStore((s) => s.field)`), not whole-store destructuring.

### 3.5 Naming & structure
- `src/lib/` = pure logic (no React, no DOM-coupling where avoidable). Testable in isolation.
- `src/components/` = React UI. May import from `lib/` but never from `app/`.
- `src/app/` = Next.js entry. May import from `components/` and `lib/`.
- File names: `PascalCase.tsx` for components, `kebab-case.ts` for everything else.

## 4. Testing standards (SWEBOK KA 4 — Software Testing)

- **Pure functions MUST have tests.** Anything in `src/lib/` that doesn't touch the DOM or React should be tested.
- **Bug fixes MUST include a regression test** that fails before the fix and passes after. See `engine.test.ts > runScoring — bug regressions` for examples.
- **Boundary tests over happy-path tests.** For numeric/string inputs, test the edges (empty, zero, max-length, Unicode, injection characters).
- **Security tests MUST cover the threat model.** See `url-guard.test.ts` (SSRF) and `sanitize.test.ts` (injection vectors).
- Tests live next to the code they test: `engine.ts` → `engine.test.ts` in the same directory.

## 5. Pull request process

1. Create a branch named `fix/<short-description>` or `feat/<short-description>`.
2. Make your changes. Keep commits focused — one logical change per commit.
3. Update the CHANGELOG under `[Unreleased]`.
4. Run `bun run lint && bun run test` — both must pass.
5. Open a PR with a description that includes:
   - What changed and why.
   - The SWEBOK KA(s) the change relates to (e.g., "KA 3 §4.5 — fault tolerance").
   - Screenshots for UI changes.
   - A note on any security implications.
6. Request review. A PR is merged only after review + green CI.

## 6. Professional practice (SWEBOK KA 11)

- Be respectful and constructive in review feedback.
- Credit prior art — if you're porting logic from an existing tool, say so in the commit message.
- Don't commit secrets. `.env` is gitignored; if you accidentally commit one, rotate it immediately.
- Report security vulnerabilities privately, not in a public issue.

## 7. Where to ask for help

- Architecture questions → `ARCHITECTURE.md` first, then open a discussion.
- Requirements questions → `REQUIREMENTS.md`.
- Security questions → `ARCHITECTURE.md §5 Security Model`.
- Anything else → open an issue with the `question` label.
